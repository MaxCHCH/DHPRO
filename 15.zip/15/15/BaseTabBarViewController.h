//
//  BaseTabBarViewController.h
//  LBJH
//
//  Created by 创投天下 on 15/9/2.
//  Copyright (c) 2015年 cttx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTabBarViewController : UITabBarController

@end
