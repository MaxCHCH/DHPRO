//
//  ThreeViewController.h
//  NavBar
//
//  Created by MissWan on 2016/10/19.
//  Copyright © 2016年  wangyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#define IWColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]

@interface ThreeViewController : UIViewController

@end
