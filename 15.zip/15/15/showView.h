//
//  showView.h
//  15
//
//  Created by 奇葩网络 on 2017/5/27.
//  Copyright © 2017年 大爷公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface showView : UIView

+ (void)showWelcomeView:(UIImage *)images;

@end
